import React, { useState } from 'react';
import { Text, SafeAreaView, StyleSheet, Button, View } from 'react-native';
import { Card } from 'react-native-paper';
import AssetExample from './components/AssetExample';

export default function App() {
  const [isToggleOn, setIsToggleOn] = useState(false);

  const handleToggle = (sans) => {
    setIsToggleOn(!isToggleOn);
    if (!isToggleOn) {
    } else {; }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
        MINECRAFT
      </Text>
      <Card>
        <AssetExample />
      </Card>
      <View style={styles.buttonContainer}>
        <Button
          title={isToggleOn ? "Desativar" : "Ativar"}
          onPress={handleToggle}
          color={isToggleOn ? "#E52800" : "#4B0082"}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#2E8B57',
    padding: 9,
  },
  paragraph: {
    marginTop: 60,
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'white',
    fontFamily: 'Calibri, Candara, Segoe, Segoe UI, Optima, Arial, sans-serif.', // Substitua pelo nome da fonte desejada
  },
  buttonContainer: {
  
    marginTop: 10,
    borderRadius: 64,
    overflow: 'hidden',
    width: 270
  },
});
