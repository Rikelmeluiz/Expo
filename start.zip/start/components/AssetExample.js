import { Text, View, StyleSheet, Image } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}><Image style={styles.logo} source={require('../assets/mine.png')} />
      <Text style={styles.paragraph}>
        RIkelme Luiz 3B
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 44,
    backgroundColor: '#2E8B57',
  },
  paragraph: {
    margin: 14,
    marginTop: 0,
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    color:'white',
    fontFamily:'Calibri, Candara, Segoe, Segoe UI, Optima, Arial, sans-serif.'
  
  },
  logo: {
    height: 129,
    width: 138,
  }
});
