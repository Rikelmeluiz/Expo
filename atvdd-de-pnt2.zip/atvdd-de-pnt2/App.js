import { useState } from 'react';
import { Text, SafeAreaView, StyleSheet, Button, TextInput } from 'react-native';

export default function App() {
  const [name, setName] = useState('');

  return (
    <SafeAreaView style={styles.container}>
      <Text style={{ color: 'white', marginBottom: 10, fontSize: 16 }}>
        O Nome salvo de: {name}
      </Text>
      <TextInput
        placeholder="Coloque seu nome aqui"
        style={{ ...styles.textInput, opacity: 0.7 }}
        onChangeText={(text) => setName(text)}
        value={name}
      />
      <Button
        title="Salvar o nick"
        onPress={() => alert(`Nome salvo de: ${name}`)}
        style={styles.saveButton}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
    backgroundColor: 'purple',
  },
  textInput: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'left',
    backgroundColor: 'magenta',
    paddingVertical: 13,
    paddingHorizontal: 40,
    outline: 'none',
    borderRadius: 20,
    marginBottom: 10,
  },
  saveButton: {
    borderRadius: 30,
  },
});
