import React, { useState } from 'react';
import { Text, SafeAreaView, StyleSheet, ScrollView, FlatList, TouchableOpacity } from 'react-native';

const Data = [
  'Macarrão',
  'Batata',
  'Arroz',
  'Nuggets',
  'Miojo',
  'Manteiga',
  'Salgadinho',
  'Uva',
];

export default function App() {
  const [selectedItem, setSelectedItem] = useState(null);

  const handleItemClick = (item) => {
    setSelectedItem(item);
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>LISTA</Text>
      <ScrollView style={styles.scrollViewContainer}>
        <FlatList
          data={Data}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.button}
              onPress={() => handleItemClick(item)}
            >
              <Text style={styles.buttonText}>{item}</Text>
            </TouchableOpacity>
          )}
          keyExtractor={(item) => item}
          numColumns={2}
          style={styles.flatListContainer}
          contentContainerStyle={styles.flatListContent}
        />
      </ScrollView>
      {selectedItem && (
        <Text style={styles.selectedItemText}>
          Você escolheu: {selectedItem}
        </Text>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#FF4500',
    padding: 8,
  },
  title: {
    margin: 33,
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'white',
  },
  scrollViewContainer: {
    alignItems: 'center',
    padding: 2,
  },
  flatListContainer: {
    backgroundColor: 'black',
    borderRadius: 5,
    display: 'flex',
    alignItems: 'center',
  },
  flatListContent: {
    justifyContent: 'center',
  },
  button: {
    backgroundColor: '#B0C4DE',
    padding: 10,
    margin: 5,
    borderRadius: 5,
    width: 100,
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#2F4F4F',
  },
  selectedItemText: {
    textAlign: 'center',
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 20,
  },
});
