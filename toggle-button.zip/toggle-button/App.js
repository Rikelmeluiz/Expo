import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableWithoutFeedback } from 'react-native';

export default function App() {
  const [isActive, setIsActive] = useState(false);

  const handleToggle = () => {
    setIsActive(!isActive);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.fint}>Aperte abaixo</Text>
      <TouchableWithoutFeedback onPress={handleToggle}>
        <View style={[styles.toggleSwitch, { backgroundColor: isActive ? '#4CAF50' : 'red' }]}>
          <View style={[styles.circle, { marginLeft: isActive ? '60%' : 0 }]} />
        </View>
      </TouchableWithoutFeedback>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#041F50'
  },
  fint: {
    fontSize: 30,
    marginBottom: 15,
    color: 'white'
  },
  toggleSwitch: {
    width: 60,
    height: 30,
    borderRadius: 15,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 5,
  },
  circle: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: 'white',
    color: 'red',
  },
});

